
DROP INDEX idx_checkout_transactions_session;
DROP INDEX idx_cart_items_session;
DROP TABLE checkout_transactions;
DROP TABLE cart_items;
DROP TABLE cart_sessions;
DROP TABLE licenses;
