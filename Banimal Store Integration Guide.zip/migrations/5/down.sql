
DROP INDEX idx_app_configuration_category;
DROP INDEX idx_payment_transactions_status;
DROP INDEX idx_payment_transactions_session;
DROP TABLE payment_transactions;
DROP TABLE app_configuration;
