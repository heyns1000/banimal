
DROP INDEX idx_brands_active;
DROP INDEX idx_brands_name;
DROP INDEX idx_brands_category;
DROP INDEX idx_brands_tier;
DROP INDEX idx_brands_system;
DROP TABLE brands;
