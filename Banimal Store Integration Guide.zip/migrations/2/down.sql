
DROP TABLE brand_tiers;
DROP TABLE brand_systems;
